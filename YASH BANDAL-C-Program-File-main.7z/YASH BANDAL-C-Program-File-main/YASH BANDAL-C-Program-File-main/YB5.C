#include<stdio.h>
#include<conio.h>
int main()
{
int i,n;
clrscr();
printf("enter the value of n:");
scanf("%d",&n);
printf("no sfquare cube square root\n",n);

getch();
return 0;
}
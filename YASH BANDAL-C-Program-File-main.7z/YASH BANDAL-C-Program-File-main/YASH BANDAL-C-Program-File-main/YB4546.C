#include<stdio.h>
#include<conio.h>
  int main()
  {
  int i;
  clrscr();
  printf("enter a integer");
  scanf("%d",&i);
  printf("hexadecimal is %x\n",i);
  printf("octal is %o\n",i);
  getch();
  return 0;
  }
